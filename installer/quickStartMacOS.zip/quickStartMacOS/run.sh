# execute barcodeDesigner_v1.0.jar
java/jdk-16.jdk/Contents/Home/bin/java --module-path java/javafx-sdk-16/lib --add-modules=javafx.controls,javafx.fxml,javafx.graphics -jar barcodesDesigner_v1.0.jar
