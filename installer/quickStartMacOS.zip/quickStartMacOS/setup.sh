#!/bin/bash

# set up for macOs
# create folder
mkdir java

# download javafx
cd java
curl -o javafx.zip 'https://download2.gluonhq.com/openjfx/16/openjfx-16_osx-x64_bin-sdk.zip'

# unzip this zip file
unzip -a javafx.zip

# remove zip
rm javafx.zip

# download java sdk
curl -o java.tar.gz 'https://download.java.net/java/GA/jdk16/7863447f0ab643c585b9bdebf67c69db/36/GPL/openjdk-16_osx-x64_bin.tar.gz'

# untar this zip file
tar -xzf java.tar.gz

# remove zip
rm java.tar.gz

# go back
cd ..
