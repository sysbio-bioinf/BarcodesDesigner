#!/bin/bash

java/jdk-16/bin/java --module-path java/javafx-sdk-16/lib --add-modules=javafx.controls,javafx.fxml,javafx.graphics -jar barcodesDesigner_v1.0.jar
